package Amazon;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class CheckCase {

	static WebDriver driver = null;
    static WebDriverWait wait = null;
    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","/home/rafikahmed/Documents/LP2/geckodriver-v0.22.0-linux64/geckodriver");	
		driver = new FirefoxDriver();
    }
    
	
    @Test
    public void testCaseS() throws InterruptedException 
    {
        driver.get("http://wwww.amazon.com");
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div/a[2]/span[1]")).click();
        
	//Check Case sensitivity of Valid Username and  Valid Password in Upper Case
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("Valid Username(Uppercase)");
		Thread.sleep(1500);		 		 
		 
		driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Valid Password(Uppercase)");
		Thread.sleep(1000);		 
		 
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		Thread.sleep(1000);
        
        // Test
        Assert.assertTrue(driver.getTitle().equals("Amazon Sign In"));
        Thread.sleep(500);
    }
    
    @AfterClass
    public static void CleanUp()
    {
        driver.quit();
    }
}
