package Amazon;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

import org.junit.Test;

public class IIcase {
	
	static WebDriver driver = null;
    static WebDriverWait wait = null;
    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","/home/rafikahmed/Documents/LP2/geckodriver-v0.22.0-linux64/geckodriver");	
		driver = new FirefoxDriver();
    }
    
	
    @SuppressWarnings("deprecation")
	@Test
    public void testLoginII() throws InterruptedException {
        driver.get("http://wwww.amazon.com");
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div/a[2]/span[1]")).click();
      
        //Login using In-Valid UserId/Mobile and In-Valid Password
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("In-Valid Username");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("In-Valid Password");
		Thread.sleep(1000);		 
		 
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		Thread.sleep(1000);		
        
		// Test
		Assert.assertTrue(driver.getTitle().equals("Amazon Sign In"));
		Thread.sleep(3500);
        
	}
    
    @AfterClass
    public static void CleanUp(){
        driver.quit();
    }

}
