package Amazon;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class EmptySearch 
{

	static WebDriver driver = null;
    static WebDriverWait wait = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","Gecko Driver (.exe file) System Path");	
		driver = new FirefoxDriver();
    }
    
    @Before
    public void setUp() throws Exception 
    {
        driver.get("http://wwww.amazon.com");
    }
	
    @SuppressWarnings("deprecation")
	@Test
    public void testEmptysearch() throws InterruptedException 
    {
        driver.get("http://wwww.amazon.com");
        Thread.sleep(1000);
        
		//SearchBar - " (Empty)"
		driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys(" ");
		driver.findElement(By.xpath("/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input")).click();
		
		// Test
		Assert.assertTrue(driver.getTitle().equals("Amazon.com: "));
		Thread.sleep(1000);
    }
    
    @AfterClass
    public static void CleanUp()
    {
        driver.quit();
    }

}
