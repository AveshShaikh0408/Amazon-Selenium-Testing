package Amazon;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class HomePage {

	static WebDriver driver = null;
    static WebDriverWait wait = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","Gecko Driver (.exe file) System Path");	
		driver = new FirefoxDriver();
    }
    
   
    @SuppressWarnings("deprecation")
	@Test
    public void testHomePage() throws InterruptedException 
    {
        driver.get("http://wwww.amazon.com");
        	
		// Test
		Assert.assertTrue(driver.getTitle().equals("Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more"));
		System.out.println("Passed..!!! We are at Home Page");
		Thread.sleep(2500);
		
    }
    
    @AfterClass
    public static void CleanUp()
    {
        driver.quit();
    }

}
