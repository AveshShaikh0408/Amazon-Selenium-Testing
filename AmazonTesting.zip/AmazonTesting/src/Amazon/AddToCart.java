package Amazon;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class AddToCart {
	static WebDriver driver = null;
    static WebDriverWait wait = null;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","Gecko Driver (.exe file) System Path");	
		driver = new FirefoxDriver();
    }
    

    @SuppressWarnings("deprecation")
	@Test
    public void testAddToCart() throws InterruptedException {
        driver.get("http://wwww.amazon.com");
        driver.findElement(By.linkText("Today's Deals")).click();
        wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Today's Deals")));
        
        
        //driver.findElement(By.xpath("/html/body/div[2]/div[4]/div/div[2]/div[2]/div/div[2]/div/div/div/div[4]/div/div[2]/div/div/div[8]/div/span/span/span/button")).click();
        driver.findElement(By.id("a-autoid-2-announce")).click();
        wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nav-cart")));
        
        driver.findElement(By.id("nav-cart")).click();
        wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("sc-active-cart")));
        
        // Test
        Assert.assertTrue(driver.getTitle().equals("Amazon.com Shopping Cart"));
        Thread.sleep(3500);
        
    }
    
    @AfterClass
    public static void CleanUp()
    {
        driver.quit();
    }

}
