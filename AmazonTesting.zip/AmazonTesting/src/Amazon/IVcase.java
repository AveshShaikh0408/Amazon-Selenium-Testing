package Amazon;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

import org.junit.Test;

public class IVcase {
	
	static WebDriver driver = null;
    static WebDriverWait wait = null;
    @BeforeClass
    public static void setUpBeforeClass() throws Exception 
    {
    	System.setProperty("webdriver.gecko.driver","Gecko Driver (.exe file) System Path");	
		driver = new FirefoxDriver();
    }
    
    @Before
    public void setUp() throws Exception {
        driver.get("http://wwww.amazon.com");
    }
	
    @SuppressWarnings("deprecation")
	@Test
    public void testLoginIV() throws InterruptedException {
   
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/div[1]/header/div/div[2]/div[2]/div/a[2]/span[1]")).click();
        
      //Login using In-Valid UserId/Mobile and Valid Password
        driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).sendKeys("In-Valid UserId");
		Thread.sleep(1000);		 
		 
		driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Valid Password");
		Thread.sleep(1000);		 
		 
		driver.findElement(By.xpath("//*[@id=\"signInSubmit\"]")).click();
		Thread.sleep(1000);		 
		        
        // Test
		 Assert.assertTrue(driver.getTitle().equals("Amazon Sign In"));
		 Thread.sleep(500);
    }
    
    @AfterClass
    public static void CleanUp()
    {
       driver.quit();
    }

}
